<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>My Courses</h1>

    <?php if($materials->count()): ?>
        <div class="row">
            <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($material->title); ?></h5>
                            <p><strong>Subject:</strong> <?php echo e($material->subject); ?></p>
                            <p><strong>Type:</strong> <?php echo e(ucfirst($material->type)); ?></p>
                            <a href="<?php echo e(route('student.materials.view', $material->id)); ?>" target="_blank" class="btn btn-primary">View</a>
                            <a href="<?php echo e(route('student.materials.download', $material->id)); ?>" class="btn btn-success">Download</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <p>You have no assigned materials yet.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/student/courses/index.blade.php ENDPATH**/ ?>