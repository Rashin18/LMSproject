<!-- resources/views/eoi/form.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h4>Expression of Interest</h4>
        </div>
      <!-- resources/views/eoi/create.blade.php -->
<form method="POST" action="<?php echo e(route('eoi.store')); ?>" id="eoi-form">
    <?php echo csrf_field(); ?> <!-- Critical for Laravel forms -->
    
    <!-- Guest User Fields -->
    <?php if(auth()->guard()->guest()): ?>
    <div class="mb-3">
        <label for="name" class="form-label">Full Name *</label>
        <input type="text" class="form-control" name="name" required>
    </div>
    
    <div class="mb-3">
        <label for="email" class="form-label">Email *</label>
        <input type="email" class="form-control" name="email" required>
    </div>
    <?php endif; ?>
    
    <div class="mb-3">
        <label for="project_details" class="form-label">Project Details *</label>
        <textarea class="form-control" name="project_details" rows="5" required></textarea>
    </div>

    

    <button type="submit" class="btn btn-primary" id="submit-btn">Submit EOI</button>
</form>

<!-- Add this for error display -->
<?php if($errors->any()): ?>
<div class="alert alert-danger mt-3">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
document.getElementById('eoi-form').addEventListener('submit', function(e) {
    const btn = document.getElementById('submit-btn');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status"></span> Submitting...';
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/eoi/create.blade.php ENDPATH**/ ?>