<?php $__env->startComponent('mail::message'); ?>
# Application Approved: <?php echo new \Illuminate\Support\EncodedHtmlString($application->proposal->project_title); ?>


Your application has been officially approved!

**Project Title:** <?php echo new \Illuminate\Support\EncodedHtmlString($application->proposal->project_title); ?>  
**Approval Date:** <?php echo new \Illuminate\Support\EncodedHtmlString(now()->format('F j, Y')); ?>


<?php $__env->startComponent('mail::panel'); ?>
Congratulations! Your project is now approved and will move forward.
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::button', ['url' => $dashboardUrl]); ?>
Access Your Dashboard
<?php echo $__env->renderComponent(); ?>

If you have any questions, please contact our support team.

Thanks,  
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/emails/applications/approved.blade.php ENDPATH**/ ?>