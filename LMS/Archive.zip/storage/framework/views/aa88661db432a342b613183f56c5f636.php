<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">
                Affiliation: <?php echo e($affiliation->application->proposal->project_title); ?>

            </h6>
            <?php if($affiliation->status === 'submitted'): ?>
            <form action="<?php echo e(route('admin.affiliations.approve', $affiliation)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <button type="submit" class="btn btn-success">
                    <i class="fas fa-check"></i> Approve
                </button>
            </form>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <div class="row mb-4">
                <div class="col-md-6">
                    <h5>Project Details</h5>
                    <p><strong>Title:</strong> <?php echo e($affiliation->application->proposal->project_title); ?></p>
                    <p><strong>Budget:</strong> INR <?php echo e(number_format($affiliation->application->proposal->budget, 2)); ?></p>
                </div>
                <div class="col-md-6">
                    <h5>Affiliation Details</h5>
                    <p><strong>Status:</strong> 
                        <span class="badge bg-<?php echo e($affiliation->status === 'approved' ? 'success' : 'warning'); ?>">
                            <?php echo e(ucfirst($affiliation->status)); ?>

                        </span>
                    </p>
                    <p><strong>Submitted:</strong> <?php echo e($affiliation->created_at->format('M j, Y g:i a')); ?></p>
                </div>
            </div>
            
            <h5>Affiliation Information</h5>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <?php $__currentLoopData = $affiliation->form_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e(ucfirst(str_replace('_', ' ', $key))); ?></th>
                        <td><?php echo e(is_array($value) ? implode(', ', $value) : $value); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/admin/affiliations/show.blade.php ENDPATH**/ ?>