<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>LMS - Learning Management System</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <!-- Bootstrap & Custom CSS -->
  <link href="<?php echo e(asset('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/css/main.css')); ?>" rel="stylesheet">

  <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body class="index-page bg-white text-dark">

  
  <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
    <div class="container">
    <a class="navbar-brand" href="<?php echo e(Auth::check() ? (
      Auth::user()->role === 'superadmin' ? route('superadmin.dashboard') : 
      (Auth::user()->role === 'admin' ? route('admin.dashboard') : 
      (Auth::user()->role === 'atc' ? route('atc.dashboard') :
      (Auth::user()->role === 'applicant' ? route('applicant.dashboard') :
      (Auth::user()->role === 'teacher' ? route('teacher.dashboard') : 
      route('student.dashboard')))))
    ) : url('/')); ?>">
  <img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="Logo" style="height: 40px;">
</a>



      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse justify-content-end" id="navbarMain">
        <?php if(auth()->guard()->check()): ?>
          <ul class="navbar-nav">
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle text-dark" href="#" id="navbarUserDropdown" role="button" data-bs-toggle="dropdown">
                <?php echo e(Auth::user()->name); ?> <small>(<?php echo e(ucfirst(Auth::user()->role)); ?>)</small>
              </a>
              <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                <li><a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>">Edit Profile</a></li>
                <li><hr class="dropdown-divider"></li>
                <li>
                  <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="dropdown-item text-danger">Logout</button>
                  </form>
                </li>
              </ul>
            </li>
          </ul>
        <?php endif; ?>

        <?php if(auth()->guard()->guest()): ?>
          <ul class="navbar-nav">
            <li class="nav-item"><a href="<?php echo e(route('login')); ?>" class="nav-link text-dark">Login</a></li>
            
            
          </ul>
        <?php endif; ?>

      </div>
    </div>
  </nav>

  <?php if($activeAnnouncements->isNotEmpty()): ?>
    <div class="announcement-bar bg-warning bg-opacity-10 border-bottom border-warning">
        <div class="container py-2">
            <div class="alert alert-warning mb-0">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <?php $__currentLoopData = $activeAnnouncements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-2">
                                <strong><?php echo e($announcement->title); ?></strong>
                                <p class="mb-0"><?php echo e($announcement->message); ?></p>
                                <?php if($announcement->start_at || $announcement->end_at): ?>
                                    <small class="text-muted">
                                        <?php echo e($announcement->start_at?->format('M j')); ?> - 
                                        <?php echo e($announcement->end_at?->format('M j, Y')); ?>

                                    </small>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

  
  <main class="main py-4">
    <?php echo $__env->yieldContent('content'); ?>
  </main>

  
  <footer id="footer" class="footer border-top py-4 mt-5 bg-light">
    <div class="container text-center">
      <p class="mb-0 text-muted">&copy; <?php echo e(date('Y')); ?> My LMS. All rights reserved.</p>
    </div>
  </footer>

  <!-- Scripts -->
  <script src="<?php echo e(asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/layouts/app.blade.php ENDPATH**/ ?>