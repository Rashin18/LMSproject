<?php echo e($slot); ?>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/vendor/mail/text/panel.blade.php ENDPATH**/ ?>