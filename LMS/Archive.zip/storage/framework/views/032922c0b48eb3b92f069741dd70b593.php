<!DOCTYPE html>
<html>
<head>
    <title>System Reports - <?php echo e(now()->format('Y-m-d')); ?></title>
    <style>
        body { font-family: Arial, sans-serif; }
        h1 { color: #2d3748; font-size: 24px; }
        h2 { color: #4a5568; font-size: 18px; margin-top: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .badge { background-color: #4299e1; color: white; padding: 2px 6px; border-radius: 10px; font-size: 12px; }
    </style>
</head>
<body>
    <h1>System Reports - <?php echo e(now()->format('Y-m-d')); ?></h1>
    <p>Generated on: <?php echo e(now()->format('Y-m-d H:i:s')); ?></p>
    <p>Date range: <?php echo e($data['filters']['start']); ?> to <?php echo e($data['filters']['end']); ?></p>

    <h2>System Overview</h2>
    <table>
        <tr>
            <th>Metric</th>
            <th>Value</th>
        </tr>
        <tr>
            <td>Total Users</td>
            <td><?php echo e($data['system']['total_users']); ?></td>
        </tr>
        <tr>
            <td>Active Today</td>
            <td><?php echo e($data['system']['active_today']); ?></td>
        </tr>
        <tr>
            <td>New This Week</td>
            <td><?php echo e($data['system']['new_this_week']); ?></td>
        </tr>
    </table>

    <h2>User Statistics</h2>
    <table>
        <tr>
            <th>Role</th>
            <th>Count</th>
        </tr>
        <?php $__currentLoopData = $data['user']['by_role']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(ucfirst($role)); ?></td>
            <td><span class="badge"><?php echo e($count); ?></span></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <h2>Recent Activity (Last 10)</h2>
    <table>
        <tr>
            <th>Date</th>
            <th>User</th>
            <th>Action</th>
            <th>IP Address</th>
        </tr>
        <?php $__currentLoopData = $data['audit']->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($log->created_at->format('Y-m-d H:i')); ?></td>
            <td><?php echo e($log->user->name ?? 'System'); ?></td>
            <td><?php echo e($log->action); ?></td>
            <td><?php echo e($log->ip_address); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/superadmin/reports/export-pdf.blade.php ENDPATH**/ ?>