<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card shadow">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h3>Manage Assignments</h3>
            <div>
                <a href="<?php echo e(route('admin.assignments.create')); ?>" class="btn btn-light">
                    <i class="fas fa-plus"></i> Create New
                </a>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <?php echo $__env->make('admin.assignments.partials.search', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                
                <table class="table table-hover">
                    <thead class="thead-light">
                        <tr>
                            <th>Title</th>
                            <th>Course</th>
                            <th>Teacher</th>
                            <th>Due Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($assignment->title); ?></td>
                            <td><?php echo e($assignment->course->title); ?></td>
                            <td><?php echo e($assignment->teacher->name); ?></td>
                            <td><?php echo e($assignment->due_date); ?></td>
                            <td>
                                <span class="badge badge bg-<?php echo e($assignment->status === 'graded' ? 'success' : 'warning'); ?> ">
                                    <?php echo e(ucfirst($assignment->status)); ?>

                                </span>
                            </td>
                            <td>
    <div class="btn-group btn-group-sm" role="group">
        <a href="<?php echo e(route('admin.assignments.show', $assignment)); ?>" 
           class="btn btn-info" title="View">
            View<i class="fas fa-eye"></i>
        </a>
        <a href="<?php echo e(route('admin.assignments.edit', $assignment)); ?>" 
           class="btn btn-primary" title="Edit">Edit
            <i class="fas fa-edit"></i>
        </a>
        <form class="d-inline" action="<?php echo e(route('admin.assignments.destroy', $assignment)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger" 
                    onclick="return confirm('Are you sure you want to delete this assignment?')" 
                    title="Delete"> Delete
                <i class="fas fa-trash"></i>
            </button>
        </form>
    </div>
</td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center">No assignments found</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php echo e($assignments->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/admin/assignments/index.blade.php ENDPATH**/ ?>