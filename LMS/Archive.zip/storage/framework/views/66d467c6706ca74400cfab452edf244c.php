<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Student Progress Overview</h2>

    <?php if($materials->count()): ?>
        <div class="accordion" id="materialAccordion">
            <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="heading<?php echo e($index); ?>">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($index); ?>">
                            <?php echo e($material->title); ?> (<?php echo e(ucfirst($material->type)); ?>)
                        </button>
                    </h2>
                    <div id="collapse<?php echo e($index); ?>" class="accordion-collapse collapse" data-bs-parent="#materialAccordion">
                        <div class="accordion-body">
                            <?php if($material->assignedStudents->count()): ?>
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Student Name</th>
                                            <th>Email</th>
                                            <th>Watched</th>
                                            <th>Progress (%)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $material->assignedStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($student->name); ?></td>
        <td><?php echo e($student->email); ?></td>
        <td>
            <span class="badge bg-secondary">
                <?php echo e($student->pivot->is_watched ? 'Yes' : 'No'); ?>

            </span>
        </td>
        <td>
            <?php echo e($student->pivot->progress); ?>%
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </tbody>
                                </table>
                            <?php else: ?>
                                <div class="text-muted">No students assigned.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="alert alert-info">No materials uploaded yet.</div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/teacher/materials/progress_overview.blade.php ENDPATH**/ ?>