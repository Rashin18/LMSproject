<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col">
            <h1 class="h3 mb-0">Backup Management</h1>
        </div>
        <div class="col-auto">
            <form action="<?php echo e(route('superadmin.backups.create')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Create New Backup
                </button>
            </form>
        </div>
    </div>

    <div class="card shadow">
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Filename</th>
                            <th>Size</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $backupFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $backup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($backup['filename']); ?></td>
                                <td><?php echo e(formatBytes($backup['size'])); ?></td>
                                <td><?php echo e($backup['date']); ?></td>
                                <td>
                                    <div class="btn-group">
                                        <a href="<?php echo e(route('superadmin.backups.download', $backup['filename'])); ?>" 
                                           class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-download"></i> Download
                                        </a>
                                        <form action="<?php echo e(route('superadmin.backups.restore')); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="backup_file" value="<?php echo e($backup['filename']); ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-warning" 
                                                    onclick="return confirm('WARNING: This will overwrite your current database. Continue?')">
                                                <i class="fas fa-undo"></i> Restore
                                            </button>
                                        </form>
                                        <form action="<?php echo e(route('superadmin.backups.destroy', $backup['filename'])); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger" 
                                                    onclick="return confirm('Are you sure you want to delete this backup?')">
                                                <i class="fas fa-trash"></i> Delete
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center">No backups available</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/superadmin/backups/index.blade.php ENDPATH**/ ?>