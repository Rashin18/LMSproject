<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Manage Expressions of Interest</h1>
    
    <div class="card">
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Submitted</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $eois; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eoi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($eoi->id); ?></td>
                        <td><?php echo e($eoi->name); ?></td>
                        <td><?php echo e($eoi->email); ?></td>
                        <td>
                            <span class="badge bg-<?php echo e($eoi->status == 'approved' ? 'success' : 
                                ($eoi->status == 'rejected' ? 'danger' : 'warning')); ?>">
                                <?php echo e(ucfirst($eoi->status)); ?>

                            </span>
                        </td>
                        <td><?php echo e($eoi->created_at->format('d/m/Y H:i')); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.eois.show', $eoi)); ?>" class="btn btn-sm btn-primary">
                                View
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
            <?php echo e($eois->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/admin/eois/index.blade.php ENDPATH**/ ?>