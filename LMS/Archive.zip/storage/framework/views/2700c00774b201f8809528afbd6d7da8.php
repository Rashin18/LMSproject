<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h2>Proposal: <?php echo e($proposal->project_title); ?></h2>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <h5>Project Details</h5>
                    <p><strong>Title:</strong> <?php echo e($proposal->project_title); ?></p>
                    <p><strong>Budget:</strong> INR <?php echo e(number_format($proposal->budget, 2)); ?></p>
                    <p><strong>Timeline:</strong> <?php echo e($proposal->timeline); ?></p>
                </div>
                <div class="col-md-6">
                    <h5>Contact Information</h5>
                    <p><strong>Email:</strong> <?php echo e($proposal->contact_email); ?></p>
                    <p><strong>Phone:</strong> <?php echo e($proposal->contact_phone ?? 'N/A'); ?></p>
                    <p><strong>Submitted:</strong> <?php echo e($proposal->created_at->format('M j, Y g:i a')); ?></p>
                </div>
            </div>
            
            <div class="mt-4">
                <h5>Detailed Description</h5>
                <div class="border p-3 bg-light rounded">
                    <?php echo nl2br(e($proposal->detailed_description)); ?>

                </div>
            </div>
            
            <?php if($proposal->team_members): ?>
            <div class="mt-4">
                <h5>Team Members</h5>
                <div class="border p-3 bg-light rounded">
                    <?php echo nl2br(e($proposal->team_members)); ?>

                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/admin/proposals/show.blade.php ENDPATH**/ ?>