<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="mb-4 text-primary">Sent Messages</h2>
    <a href="<?php echo e(route('teacher.messages.create')); ?>" class="btn btn-sm btn-success mb-3">➕ New Message</a>

    <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card mb-3 shadow-sm">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($message->subject); ?></h5>
                <p class="card-text"><?php echo e($message->body); ?></p>
                <small class="text-muted">To: Student ID <?php echo e($message->student_id); ?> | Sent: <?php echo e($message->created_at->diffForHumans()); ?></small>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="alert alert-info">No messages sent yet.</div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/teacher/messages/index.blade.php ENDPATH**/ ?>