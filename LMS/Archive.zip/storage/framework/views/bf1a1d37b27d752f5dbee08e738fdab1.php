<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Your Materials</h1>
    <a href="<?php echo e(route('teacher.materials.create')); ?>" class="btn btn-primary mb-3">Upload New Material</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($materials->count()): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Subject</th>
                    <th>Type</th>
                    <th>Downloads</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($material->title); ?></td>
                    <td><?php echo e($material->subject); ?></td>
                    <td><?php echo e(ucfirst($material->type)); ?></td>
                    <td><?php echo e($material->download_count); ?></td>
                    <td>
                        <a href="<?php echo e(route('teacher.materials.assigned_students', $material->id)); ?>" class="btn btn-info btn-sm">Assigned Students</a>
                        <a href="<?php echo e(route('teacher.materials.view', $material->id)); ?>" class="btn btn-sm btn-primary" target="_blank" rel="noopener noreferrer">View</a>
                        <a href="<?php echo e(route('teacher.materials.download', $material->id)); ?>" class="btn btn-sm btn-success">Download</a>
                        <a href="<?php echo e(route('teacher.materials.edit', $material->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                        <form action="<?php echo e(route('teacher.materials.destroy', $material->id)); ?>" method="POST" class="d-inline-block" onsubmit="return confirm('Are you sure to delete this material?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger" type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No materials uploaded yet.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/teacher/materials/index.blade.php ENDPATH**/ ?>