<header id="header" class="header d-flex align-items-center sticky-top">
  <div class="container-fluid container-xl position-relative d-flex align-items-center">

    <a href="<?php echo e(url('/')); ?>" class="logo d-flex align-items-center me-auto">
      <img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt=""> 
      <h1 class="sitename">Learning Management System</h1>
    </a>

    <nav id="navmenu" class="navmenu">
      <ul>
        <li><a href="#hero" class="active">Home</a></li>
        <li><a href="#about">About</a></li>
        <li><a href="#services">Features</a></li>
        <li><a href="#contact">Contact</a></li>
        <!-- Add more nav links if needed -->
        <?php if(auth()->guard()->guest()): ?>
          <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
          <li><a href="<?php echo e(route('eoi.create')); ?>">EOI Submit</a></li>
        <?php endif; ?>
        
        <?php if(auth()->guard()->check()): ?>
          <li>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
              <?php echo csrf_field(); ?>
              <button class="btn btn-link nav-link" style="border: none; background: none; padding: 0; color: inherit;">Logout</button>
            </form>
          </li>
        <?php endif; ?>
      </ul>

      <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
    </nav>


    <a class="btn-getstarted" href="#about">Get Started</a>
    

  </div>
</header><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/partials/header.blade.php ENDPATH**/ ?>