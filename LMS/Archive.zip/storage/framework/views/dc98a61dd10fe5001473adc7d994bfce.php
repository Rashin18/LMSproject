<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row mb-4">
        <div class="col">
            <h1 class="text-primary">Welcome ATC</h1>
            <p class="text-muted">Manage the LMS platform – users, courses, and reports.</p>
            <?php if (isset($component)) { $__componentOriginal7ba61be6ae4c62d2088d368a74b5ebcc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ba61be6ae4c62d2088d368a74b5ebcc = $attributes; } ?>
<?php $component = App\View\Components\AnnouncementsList::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('announcements-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AnnouncementsList::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ba61be6ae4c62d2088d368a74b5ebcc)): ?>
<?php $attributes = $__attributesOriginal7ba61be6ae4c62d2088d368a74b5ebcc; ?>
<?php unset($__attributesOriginal7ba61be6ae4c62d2088d368a74b5ebcc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ba61be6ae4c62d2088d368a74b5ebcc)): ?>
<?php $component = $__componentOriginal7ba61be6ae4c62d2088d368a74b5ebcc; ?>
<?php unset($__componentOriginal7ba61be6ae4c62d2088d368a74b5ebcc); ?>
<?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/atc/dashboard.blade.php ENDPATH**/ ?>