<?php $__env->startComponent('mail::message'); ?>
# Proposal Approved: <?php echo new \Illuminate\Support\EncodedHtmlString($proposal->project_title); ?>


Your proposal has been approved! Please complete the application form by clicking the button below.

**Important:** This link will expire on <?php echo new \Illuminate\Support\EncodedHtmlString($proposal->token_expires_at->format('F j, Y')); ?>.

<?php $__env->startComponent('mail::button', ['url' => $applicationFormUrl]); ?>
Complete Application Form
<?php echo $__env->renderComponent(); ?>

If the button doesn't work, copy and paste this URL into your browser:
<?php echo new \Illuminate\Support\EncodedHtmlString($applicationFormUrl); ?>


<?php $__env->startComponent('mail::panel'); ?>
If you encounter any issues, please contact us at <?php echo new \Illuminate\Support\EncodedHtmlString(config('mail.support_email')); ?> immediately.
<?php echo $__env->renderComponent(); ?>

Thanks,  
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/emails/proposals/approved.blade.php ENDPATH**/ ?>