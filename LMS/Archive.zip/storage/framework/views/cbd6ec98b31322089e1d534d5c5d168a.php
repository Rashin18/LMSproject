<!-- resources/views/emails/eoi/submission.blade.php -->
<?php $__env->startComponent('mail::message'); ?>
# New EOI Submission Received

**From:** <?php echo new \Illuminate\Support\EncodedHtmlString($eoi->name); ?>  
**Email:** <?php echo new \Illuminate\Support\EncodedHtmlString($eoi->email); ?>  
**Submitted At:** <?php echo new \Illuminate\Support\EncodedHtmlString($eoi->created_at->format('Y-m-d H:i')); ?>


**Project Details:**  
<?php echo new \Illuminate\Support\EncodedHtmlString($eoi->project_details); ?>


<?php $__env->startComponent('mail::button', ['url' => $adminUrl]); ?>
View Full Submission
<?php echo $__env->renderComponent(); ?>

Thanks,  
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/emails/eoi/submission.blade.php ENDPATH**/ ?>