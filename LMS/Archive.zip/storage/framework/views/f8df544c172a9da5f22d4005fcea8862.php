<?php $__env->startSection('title', 'Edit User'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h3>Edit User</h3>

    <form action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label>Name</label>
            <input name="name" value="<?php echo e(old('name', $user->name)); ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Email</label>
            <input name="email" value="<?php echo e(old('email', $user->email)); ?>" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
        <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-secondary">Cancel</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/admin/users/edit.blade.php ENDPATH**/ ?>