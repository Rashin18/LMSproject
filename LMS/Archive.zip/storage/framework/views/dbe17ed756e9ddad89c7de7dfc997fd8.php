<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>