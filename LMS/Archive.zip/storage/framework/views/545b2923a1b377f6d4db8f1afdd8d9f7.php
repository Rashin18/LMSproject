<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row mb-4">
        <div class="col">
            <h1 class="text-primary">Welcome Student</h1>
            <p class="text-muted">Access your learning materials and track your progress.</p>
            <?php if (isset($component)) { $__componentOriginal7ba61be6ae4c62d2088d368a74b5ebcc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ba61be6ae4c62d2088d368a74b5ebcc = $attributes; } ?>
<?php $component = App\View\Components\AnnouncementsList::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('announcements-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AnnouncementsList::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ba61be6ae4c62d2088d368a74b5ebcc)): ?>
<?php $attributes = $__attributesOriginal7ba61be6ae4c62d2088d368a74b5ebcc; ?>
<?php unset($__attributesOriginal7ba61be6ae4c62d2088d368a74b5ebcc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ba61be6ae4c62d2088d368a74b5ebcc)): ?>
<?php $component = $__componentOriginal7ba61be6ae4c62d2088d368a74b5ebcc; ?>
<?php unset($__componentOriginal7ba61be6ae4c62d2088d368a74b5ebcc); ?>
<?php endif; ?>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body text-center">
                    <i class="bi bi-play-btn fs-1 text-primary"></i>
                    <h5 class="card-title mt-3">My Courses</h5>
                    <p class="card-text">Watch assigned lessons and course materials.</p>
                    <a href="<?php echo e(route('student.courses')); ?>" class="btn btn-outline-primary btn-sm">View Courses</a>

                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body text-center">
                    <i class="bi bi-graph-up-arrow fs-1 text-success"></i>
                    <h5 class="card-title mt-3">My Progress</h5>
                    <p class="card-text">Track what you’ve completed and upcoming tasks.</p>
                    <a href="<?php echo e(route('student.progress')); ?>" class="btn btn-outline-primary mt-3">📈 Track Progress</a>

                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body text-center">
                    <i class="bi bi-chat-left-text fs-1 text-warning"></i>
                    <h5 class="card-title mt-3">Messages</h5>
                    <p class="card-text">Check announcements and messages from teachers.</p>
                    <a href="<?php echo e(route('student.messages')); ?>" class="btn btn-outline-warning btn-sm">View Messages</a>
                </div>
            </div>
        </div>
    </div>



<!--<div class="row mt-5">
        <div class="col">
            <div class="alert alert-info shadow-sm">
                You are logged in as <strong><?php echo e(Auth::user()->name); ?></strong> (Role: <strong><?php echo e(Auth::user()->role); ?></strong>)
            </div>
        </div>
    </div> -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/student/dashboard.blade.php ENDPATH**/ ?>