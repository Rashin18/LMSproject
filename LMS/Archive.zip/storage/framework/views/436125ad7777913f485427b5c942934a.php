<?php $__env->startComponent('mail::message'); ?>
# Application Approved: <?php echo new \Illuminate\Support\EncodedHtmlString($application->proposal->project_title); ?>


Your application has been approved! Please complete the affiliation form to finalize your participation.

**Next Steps:**
1. Click the button below to access the affiliation form
2. Complete all required fields
3. Submit the form for final review

<?php $__env->startComponent('mail::button', ['url' => $affiliationFormUrl]); ?>
Complete Affiliation Form
<?php echo $__env->renderComponent(); ?>

**Important:** This link will expire on <?php echo new \Illuminate\Support\EncodedHtmlString(now()->addDays(14)->format('F j, Y')); ?>.

If you have any questions, please contact us at <?php echo new \Illuminate\Support\EncodedHtmlString(config('mail.support_email')); ?>.

Thanks,  
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/emails/applications/approved-with-affiliation.blade.php ENDPATH**/ ?>