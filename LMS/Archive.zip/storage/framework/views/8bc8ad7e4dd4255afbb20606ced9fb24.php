<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row mb-4">
        <div class="col">
            <h1 class="text-primary">Welcome Teacher</h1>
            <p class="text-muted">Manage your courses, materials, student progress, and communication.</p>
            <?php if (isset($component)) { $__componentOriginal7ba61be6ae4c62d2088d368a74b5ebcc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ba61be6ae4c62d2088d368a74b5ebcc = $attributes; } ?>
<?php $component = App\View\Components\AnnouncementsList::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('announcements-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AnnouncementsList::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ba61be6ae4c62d2088d368a74b5ebcc)): ?>
<?php $attributes = $__attributesOriginal7ba61be6ae4c62d2088d368a74b5ebcc; ?>
<?php unset($__attributesOriginal7ba61be6ae4c62d2088d368a74b5ebcc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ba61be6ae4c62d2088d368a74b5ebcc)): ?>
<?php $component = $__componentOriginal7ba61be6ae4c62d2088d368a74b5ebcc; ?>
<?php unset($__componentOriginal7ba61be6ae4c62d2088d368a74b5ebcc); ?>
<?php endif; ?>
        </div>
    </div>

    <div class="row g-4">
        <!-- Upload Materials -->
        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body text-center">
                    <i class="bi bi-upload fs-1 text-primary"></i>
                    <h5 class="card-title mt-3">Upload Materials</h5>
                    <p class="card-text">Upload videos, PDFs, and assignments.</p>
                    <a href="<?php echo e(route('teacher.materials.index')); ?>" class="btn btn-outline-primary btn-sm">Upload</a>
                </div>
            </div>
        </div>

        <!-- Manage Students -->
        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body text-center">
                    <i class="bi bi-people fs-1 text-success"></i>
                    <h5 class="card-title mt-3">Manage Students</h5>
                    <p class="card-text">View enrolled students and track activity.</p>
                    <a href="<?php echo e(route('teacher.students.index')); ?>" class="btn btn-outline-success btn-sm">View Students</a>
                </div>
            </div>
        </div>

        <!-- Student Progress -->
        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body text-center">
                    <i class="bi bi-bar-chart-line fs-1 text-warning"></i>
                    <h5 class="card-title mt-3">Student Progress</h5>
                    <p class="card-text">See who watched your videos and progress.</p>
                    <a href="<?php echo e(route('teacher.materials.progress.overview')); ?>" class="btn btn-outline-warning btn-sm">Track Progress</a>
                </div>
            </div>
        </div>

        <!-- Send Messages -->
        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body text-center">
                    <i class="bi bi-envelope fs-1 text-info"></i>
                    <h5 class="card-title mt-3">Send Messages</h5>
                    <p class="card-text">Send messages to students easily.</p>
                    <a href="<?php echo e(route('teacher.messages.index')); ?>" class="btn btn-outline-info btn-sm">Send Message</a>
                </div>
            </div>
        </div>
    </div>

<!--<div class="row mt-5">
        <div class="col">
            <div class="alert alert-info shadow-sm">
                You are logged in as <strong><?php echo e(Auth::user()->name); ?></strong> (Role: <strong><?php echo e(Auth::user()->role); ?></strong>)
            </div>
        </div>
    </div> -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/teacher/dashboard.blade.php ENDPATH**/ ?>