<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">
                Application: <?php echo e($application->proposal->project_title); ?>

            </h6>
            <?php if($application->status === 'pending'): ?>
            <form action="<?php echo e(route('admin.applications.approve', $application)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <button type="submit" class="btn btn-success">
                    <i class="fas fa-check"></i> Approve
                </button>
            </form>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <h5>Project Details</h5>
                    <p><strong>Title:</strong> <?php echo e($application->proposal->project_title); ?></p>
                    <p><strong>Budget:</strong> INR <?php echo e(number_format($application->proposal->budget, 2)); ?></p>
                    <p><strong>Timeline:</strong> <?php echo e($application->proposal->timeline); ?></p>
                </div>
                <div class="col-md-6">
                    <h5>Application Details</h5>
                    <p><strong>Status:</strong> 
                        <span class="badge bg-<?php echo e($application->status === 'approved' ? 'success' : 'warning'); ?>">
                            <?php echo e(ucfirst($application->status)); ?>

                        </span>
                    </p>
                    <p><strong>Submitted:</strong> <?php echo e($application->created_at->format('M j, Y g:i a')); ?></p>
                </div>
            </div>
            
            <hr>
            
            <h5 class="mt-4">Application Data</h5>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <?php $__currentLoopData = $application->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e(ucfirst(str_replace('_', ' ', $key))); ?></th>
                        <td><?php echo e($value); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/admin/applications/show.blade.php ENDPATH**/ ?>