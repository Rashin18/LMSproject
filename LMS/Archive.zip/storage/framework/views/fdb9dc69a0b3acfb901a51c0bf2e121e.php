<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-primary text-white">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="mb-0">Payment Details</h4>
            <a href="<?php echo e(route('admin.payments.index')); ?>" class="btn btn-light btn-sm">
                <i class="fas fa-arrow-left"></i> Back
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="row mb-4">
            <div class="col-md-6">
                <h5>Payment Information</h5>
                <table class="table table-sm table-borderless">
                    <tr>
                        <th width="40%">Payment ID:</th>
                        <td><?php echo e($payment->id); ?></td>
                    </tr>
                    <tr>
                        <th>Order ID:</th>
                        <td><?php echo e($payment->order_id); ?></td>
                    </tr>
                    <tr>
                        <th>Transaction ID:</th>
                        <td><?php echo e($payment->payment_id ?? 'N/A'); ?></td>
                    </tr>
                    <tr>
                        <th>Status:</th>
                        <td>
                            <span class="badge bg-<?php echo e($payment->status === 'completed' ? 'success' : ($payment->status === 'pending' ? 'warning' : 'danger')); ?>">
                                <?php echo e(ucfirst($payment->status)); ?>

                            </span>
                        </td>
                    </tr>
                </table>
            </div>
            <div class="col-md-6">
                <h5>Amount Details</h5>
                <table class="table table-sm table-borderless">
                    <tr>
                        <th width="40%">Amount:</th>
                        <td>₹<?php echo e($payment->formatted_amount); ?></td>
                    </tr>
                    <tr>
                        <th>Currency:</th>
                        <td><?php echo e(strtoupper($payment->currency)); ?></td>
                    </tr>
                    <tr>
                        <th>Date:</th>
                        <td><?php echo e($payment->created_at->format('d M Y, h:i A')); ?></td>
                    </tr>
                    <tr>
                        <th>User:</th>
                        <td><?php echo e($payment->user->name); ?></td>
                    </tr>
                </table>
            </div>
        </div>

        <?php if($payment->status === 'completed'): ?>
            <div class="text-center mt-3">
                <a href="<?php echo e(route('admin.payments.invoice', $payment->id)); ?>" class="btn btn-primary">
                    <i class="fas fa-file-invoice me-1"></i> Download Invoice
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/admin/payments/show.blade.php ENDPATH**/ ?>