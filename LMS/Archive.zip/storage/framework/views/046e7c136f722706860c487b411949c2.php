<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h4>Assign Students to: <?php echo e($batch->name); ?></h4>
                <a href="<?php echo e(route('admin.batches.index')); ?>" class="btn btn-light">
                    <i class="fas fa-arrow-left"></i> Back to Batches
                </a>
            </div>
        </div>
        
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-md-6">
                    <h5>Current Students (<?php echo e($currentStudents->count()); ?>)</h5>
                    <?php if($currentStudents->count() > 0): ?>
                        <ul class="list-group mb-4">
                            <?php $__currentLoopData = $currentStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo e($student->name); ?> (<?php echo e($student->email); ?>)
                                <form action="<?php echo e(route('admin.batches.students.remove', [$batch, $student])); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Remove this student?')">
                                        <i class="fas fa-user-minus"></i>
                                    </button>
                                </form>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php else: ?>
                        <div class="alert alert-info">No students assigned yet</div>
                    <?php endif; ?>
                </div>
                
                <div class="col-md-6">
                    <h5>Available Students</h5>
                    <form action="<?php echo e(route('admin.batches.assign.store', $batch)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <select name="students[]" id="students" class="form-select" multiple size="10">
                                <?php $__currentLoopData = $availableStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($student->id); ?>">
                                    <?php echo e($student->name); ?> (<?php echo e($student->email); ?>)
                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-user-plus"></i> Assign Selected Students
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->startPush('scripts'); ?>
<script>
    // Enable better multiple selection
    document.getElementById('students').addEventListener('mousedown', function(e) {
        e.preventDefault();
        const option = e.target;
        if (option.tagName === 'OPTION') {
            option.selected = !option.selected;
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/admin/batches/assign.blade.php ENDPATH**/ ?>