<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Upload New Material</h1>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('teacher.materials.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="form-group mb-3">
            <label for="title">Title <span class="text-danger">*</span></label>
            <input type="text" name="title" id="title" class="form-control" value="<?php echo e(old('title')); ?>" required>
        </div>

        <div class="form-group mb-3">
            <label for="subject">Subject <span class="text-danger">*</span></label>
            <input type="text" name="subject" id="subject" class="form-control" value="<?php echo e(old('subject')); ?>" required>
        </div>

        <div class="form-group mb-3">
            <label for="type">Type <span class="text-danger">*</span></label>
            <select name="type" id="type" class="form-control" required>
                <option value="">-- Select Type --</option>
                <option value="video" <?php echo e(old('type') == 'video' ? 'selected' : ''); ?>>Video</option>
                <option value="pdf" <?php echo e(old('type') == 'pdf' ? 'selected' : ''); ?>>PDF</option>
                <option value="assignment" <?php echo e(old('type') == 'assignment' ? 'selected' : ''); ?>>Assignment</option>
            </select>
        </div>

        <div class="form-group mb-3">
            <label for="material_file">Material File <span class="text-danger">*</span></label>
            <input type="file" name="material_file" id="material_file" class="form-control" required>
            <small class="form-text text-muted">Allowed file types: mp4, mov, avi, mkv, pdf, doc, docx, zip. Max size 10MB.</small>
        </div>

        <div class="form-group mb-3">
            <label for="student_ids">Assign to Students:</label>
            <select name="student_ids[]" id="student_ids" class="form-control" multiple>
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($student->id); ?>" <?php echo e((collect(old('student_ids'))->contains($student->id)) ? 'selected':''); ?>>
                        <?php echo e($student->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <small class="form-text text-muted">Hold Ctrl (Windows) or Cmd (Mac) to select multiple students.</small>
        </div>

        <button type="submit" class="btn btn-primary">Upload Material</button>
        <a href="<?php echo e(route('teacher.materials.index')); ?>" class="btn btn-secondary">Cancel</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/teacher/materials/create.blade.php ENDPATH**/ ?>