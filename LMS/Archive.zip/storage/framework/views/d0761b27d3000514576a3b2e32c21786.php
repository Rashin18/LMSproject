<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="text-primary mb-4">📬 Messages from Teachers</h2>

    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-3 shadow-sm">
            <div class="card-header">
                <strong><?php echo e($message->subject); ?></strong> from <strong><?php echo e($message->teacher->name ?? 'Unknown Teacher'); ?>(Teacher)</strong>
            </div>
            <div class="card-body">
                <p class="card-text"><?php echo e($message->body); ?></p>

                <!-- Reply form -->
                <form action="<?php echo e(route('student.messages.reply')); ?>" method="POST" class="mt-3">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="teacher_id" value="<?php echo e($message->teacher->id); ?>">
                    <input type="hidden" name="subject" value="Reply: <?php echo e($message->subject); ?>">

                    <div class="mb-2">
                        <textarea name="body" rows="2" class="form-control" placeholder="Type your reply..." required></textarea>
                    </div>
                    <button type="submit" class="btn btn-sm btn-primary">Send Reply</button>
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if($messages->isEmpty()): ?>
        <div class="alert alert-info">No messages available yet.</div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/student/messages/index.blade.php ENDPATH**/ ?>