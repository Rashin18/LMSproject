<!-- resources/views/eoi/form.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h4>Expression of Interest</h4>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('eoi.store')); ?>">
                <?php echo csrf_field(); ?>
                
                <div class="mb-3">
                    <label for="full_name" class="form-label">Full Name</label>
                    <input type="text" class="form-control" id="full_name" name="full_name" required>
                </div>
                
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                
                <div class="mb-3">
                    <label for="project_details" class="form-label">Project Details</label>
                    <textarea class="form-control" id="project_details" name="project_details" rows="5" required></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary">Submit EOI</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/eoi/form.blade.php ENDPATH**/ ?>