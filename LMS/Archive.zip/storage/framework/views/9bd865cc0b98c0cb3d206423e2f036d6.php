<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="mb-4 text-primary">Send Message to Student</h2>

    <form method="POST" action="<?php echo e(route('teacher.messages.store')); ?>">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="student_id" class="form-label">Select Student</label>
            <select class="form-select" name="student_id" required>
                <option value="">-- Choose Student --</option>
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($student->id); ?>"><?php echo e($student->name); ?> (<?php echo e($student->email); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="subject" class="form-label">Subject</label>
            <input type="text" name="subject" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="body" class="form-label">Message</label>
            <textarea name="body" class="form-control" rows="4" required></textarea>
        </div>

        <button type="submit" class="btn btn-primary">📤 Send Message</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/teacher/messages/create.blade.php ENDPATH**/ ?>