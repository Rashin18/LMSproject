<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h4>Assignment Details</h4>
                <div>
                    <a href="<?php echo e(route('admin.assignments.edit', $assignment)); ?>" class="btn btn-light btn-sm">
                        Edit
                    </a>
                </div>
            </div>
        </div>
        
        <div class="card-body">
            <div class="row mb-4">
                <div class="col-md-8">
                    <h3><?php echo e($assignment->title); ?></h3>
                    <p class="text-muted">Course: <?php echo e($assignment->course->name); ?></p>
                </div>
                <div class="col-md-4 text-end">
                    <span class="badge bg-<?php echo e($assignment->due_date); ?>">
                        Due: <?php echo e($assignment->due_date); ?>

                    </span>
                </div>
            </div>
            
            <div class="mb-4">
                <h5>Description</h5>
                <div class="border p-3 rounded bg-light">
                    <?php echo nl2br(e($assignment->description)); ?>

                </div>
            </div>
            
            <div class="row">
                <div class="col-md-4">
                    <div class="card mb-3">
                        <div class="card-body">
                            <h6 class="card-title">Details</h6>
                            <ul class="list-unstyled">
                                <li><strong>Max Score:</strong> <?php echo e($assignment->max_score); ?></li>
                                <li><strong>Created:</strong> <?php echo e($assignment->created_at->diffForHumans()); ?></li>
                                <li><strong>Status:</strong> 
                                    <span class="badge bg-<?php echo e($assignment->status === 'graded' ? 'success' : 'warning'); ?>">
                                        <?php echo e(ucfirst($assignment->status)); ?>

                                    </span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-8">
                    <?php if($assignment->file_path): ?>
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">Attachments</h6>
                            <a href="<?php echo e(Storage::url($assignment->file_path)); ?>" 
                               class="btn btn-outline-primary"
                               target="_blank">
                                <i class="bi bi-download"></i> Download File
                            </a>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="card-footer">
            <a href="<?php echo e(route('admin.assignments.index')); ?>" class="btn btn-secondary">
                Back to Assignments
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/admin/assignments/show.blade.php ENDPATH**/ ?>