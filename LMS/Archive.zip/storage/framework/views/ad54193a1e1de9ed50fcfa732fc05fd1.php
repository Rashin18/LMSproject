<?php $__env->startComponent('mail::message'); ?>
# New Affiliation Form Submitted

**Project Title:** <?php echo new \Illuminate\Support\EncodedHtmlString($affiliation->application->proposal->project_title); ?>  
**Submitted By:** <?php echo new \Illuminate\Support\EncodedHtmlString($affiliation->application->data['full_name'] ?? 'N/A'); ?>  
**Submission Date:** <?php echo new \Illuminate\Support\EncodedHtmlString($affiliation->created_at->format('M j, Y g:i a')); ?>


<?php $__env->startComponent('mail::button', ['url' => route('admin.affiliations.show', $affiliation)]); ?>
Review Affiliation
<?php echo $__env->renderComponent(); ?>

Thanks,  
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/emails/affiliations/submitted.blade.php ENDPATH**/ ?>