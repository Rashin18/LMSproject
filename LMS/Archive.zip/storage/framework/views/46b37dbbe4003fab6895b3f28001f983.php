<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">Submitted Proposals</h6>
            <div>
                <a href="<?php echo e(route('admin.eois.index')); ?>" class="btn btn-sm btn-secondary">
                    <i class="fas fa-arrow-left mr-1"></i> Back to EOIs
                </a>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="proposalsTable" width="100%" cellspacing="0">
                    <thead class="thead-light">
                        <tr>
                            <th>ID</th>
                            <th>Project Title</th>
                            <th>Submitted By</th>
                            <th>Budget</th>
                            <th>Status</th>
                            <th>Submitted</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $proposals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proposal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>PR-<?php echo e($proposal->id); ?></td>
                            <td><?php echo e(Str::limit($proposal->project_title, 30)); ?></td>
                            <td><?php echo e($proposal->contact_email); ?></td>
                            <td>INR <?php echo e(number_format($proposal->budget, 2)); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($proposal->status === 'approved' ? 'success' : ($proposal->status === 'rejected' ? 'danger' : 'warning')); ?>">
                                    <?php echo e(ucfirst($proposal->status)); ?>

                                </span>
                            </td>
                            <td><?php echo e($proposal->created_at->format('M d, Y')); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.proposals.show', $proposal)); ?>" class="btn btn-sm btn-primary">
                                    <i class="fas fa-eye"></i> View
                                </a>
                                <?php if($proposal->status === 'pending'): ?>
                                <form action="<?php echo e(route('admin.proposals.approve', $proposal)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button type="submit" class="btn btn-sm btn-success">
                                        <i class="fas fa-check"></i> Approve
                                    </button>
                                </form>

                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center">No proposals found</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if($proposals->hasPages()): ?>
            <div class="mt-3">
                <?php echo e($proposals->links()); ?>

            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#proposalsTable').DataTable({
            responsive: true,
            columnDefs: [
                { orderable: false, targets: -1 } // Disable sorting for actions column
            ]
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/admin/proposals/index.blade.php ENDPATH**/ ?>