<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">📈 My Progress</h2>

    <?php if($materials->count()): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Material</th>
                    <th>Subject</th>
                    <th>Type</th>
                    <th>Watched</th>
                    <th>Progress</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($material->title); ?></td>
                        <td><?php echo e($material->subject); ?></td>
                        <td><?php echo e(ucfirst($material->type)); ?></td>
                        <td>
                            <?php if($material->pivot->is_watched): ?>
                                <span class="badge bg-success">Yes</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">No</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="progress">
                                <div class="progress-bar" role="progressbar" style="width: <?php echo e($material->pivot->progress ?? 0); ?>%">
                                    <?php echo e($material->pivot->progress ?? 0); ?>%
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="alert alert-info">No assigned materials yet.</div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/student/progress/index.blade.php ENDPATH**/ ?>