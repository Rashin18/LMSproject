<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-primary text-white">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="mb-0">Payment History</h4>
            <a href="<?php echo e(route('admin.payments.create')); ?>" class="btn btn-light btn-sm">
                <i class="fas fa-plus"></i> New Payment
            </a>
        </div>
    </div>
    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-hover">
                <thead class="bg-light">
                    <tr>
                        <th>ID</th>
                        <th>User</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($payment->id); ?></td>
                            <td><?php echo e($payment->user->name); ?></td>
                            <td>₹<?php echo e($payment->formatted_amount); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($payment->status === 'completed' ? 'success' : ($payment->status === 'pending' ? 'warning' : 'danger')); ?>">
                                    <?php echo e(ucfirst($payment->status)); ?>

                                </span>
                            </td>
                            <td><?php echo e($payment->created_at->format('d M Y, h:i A')); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.payments.show', $payment->id)); ?>" class="btn btn-sm btn-info">
                                   View <i class="fas fa-eye"></i>
                                </a>
                                <?php if($payment->status === 'completed'): ?>
                                    <a href="<?php echo e(route('admin.payments.invoice', $payment->id)); ?>" class="btn btn-sm btn-primary">
                                       Download <i class="fas fa-file-invoice"></i>
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center">No payments found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($payments->hasPages()): ?>
            <div class="d-flex justify-content-center mt-4">
                <?php echo e($payments->links()); ?>

            </div>
        <?php endif; ?>
        
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/admin/payments/index.blade.php ENDPATH**/ ?>