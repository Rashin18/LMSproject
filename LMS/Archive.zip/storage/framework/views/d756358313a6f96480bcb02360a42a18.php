<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>EOI Details</h1>
    
    <div class="card">
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-6">
                    <strong>Name:</strong> <?php echo e($eoi->name); ?>

                </div>
                <div class="col-md-6">
                    <strong>Email:</strong> <?php echo e($eoi->email); ?>

                </div>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <strong>Status:</strong>
                    <span class="badge bg-<?php echo e($eoi->status == 'approved' ? 'success' : 
                        ($eoi->status == 'rejected' ? 'danger' : 'warning')); ?>">
                        <?php echo e(ucfirst($eoi->status)); ?>

                    </span>
                </div>
                <div class="col-md-6">
                    <strong>Submitted:</strong> <?php echo e($eoi->created_at->format('d/m/Y H:i')); ?>

                </div>
            </div>
            
            <div class="mb-3">
                <strong>Project Details:</strong>
                <div class="border p-3 mt-2">
                    <?php echo nl2br(e($eoi->project_details)); ?>

                </div>
            </div>
            
            <form action="<?php echo e(route('admin.eois.update-status', $eoi)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            
            <div class="row">
        <div class="col-md-4">
            <select name="status" class="form-select">
                <option value="pending" <?php echo e($eoi->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                <option value="approved" <?php echo e($eoi->status == 'approved' ? 'selected' : ''); ?>>Approve (will send email)</option>
                <option value="rejected" <?php echo e($eoi->status == 'rejected' ? 'selected' : ''); ?>>Rejected</option>
            </select>
        </div>
        <div class="col-md-4">
            <button type="submit" class="btn btn-primary">Update Status</button>
        </div>
    </div>
</form>
        </div>
    </div>
    
    <a href="<?php echo e(route('admin.eois.index')); ?>" class="btn btn-secondary mt-3">Back to List</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/admin/eois/show.blade.php ENDPATH**/ ?>