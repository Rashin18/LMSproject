<?php if($announcements->isNotEmpty()): ?>
<div class="card mb-4 shadow-sm">
    <div class="card-header bg-primary text-white">
        <h5 class="mb-0"><i class="bi bi-megaphone"></i> Announcements</h5>
    </div>
    <div class="card-body">
        <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="mb-3 pb-3 border-bottom">
            <h6 class="text-primary"><?php echo e($announcement->title); ?></h6>
            <p class="mb-2"><?php echo e($announcement->message); ?></p>
            <small class="text-muted d-block">
                <i class="bi bi-calendar"></i> 
                <?php if($announcement->start_at || $announcement->end_at): ?>
                    Valid: <?php echo e($announcement->start_at?->format('M d, Y') ?? 'Immediately'); ?>

                    <?php if($announcement->end_at): ?>
                        - <?php echo e($announcement->end_at->format('M d, Y')); ?>

                    <?php endif; ?>
                <?php else: ?>
                    No expiration
                <?php endif; ?>
                • Posted: <?php echo e($announcement->created_at->format('M d, Y')); ?>

            </small>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/components/announcements-list.blade.php ENDPATH**/ ?>