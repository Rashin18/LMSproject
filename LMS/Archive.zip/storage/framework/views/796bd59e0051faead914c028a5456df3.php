<?php echo e($slot); ?>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>