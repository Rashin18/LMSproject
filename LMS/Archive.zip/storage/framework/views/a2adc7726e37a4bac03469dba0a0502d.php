<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Manage Batches</h1>
        <a href="<?php echo e(route('admin.batches.create')); ?>" class="btn btn-primary">
            Create New Batch
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <?php if($batches->count() > 0): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($batch->name); ?></td>
                            <td><?php echo e(Str::limit($batch->description, 50)); ?></td>
                            <td>
                                <div class="d-flex gap-2">
                                    <a href="<?php echo e(route('admin.batches.edit', $batch)); ?>" class="btn btn-sm btn-outline-primary">
                                        Edit
                                    </a>
                                    <!-- Add this new button -->
                                    <a href="<?php echo e(route('admin.batches.assign', $batch)); ?>" 
                                       class="btn btn-sm btn-outline-success">
                                        Assign Students
                                    </a>
                                    <form action="<?php echo e(route('admin.batches.destroy', $batch)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure?')">
                                            Delete
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($batches->links()); ?>

            <?php else: ?>
                <div class="alert alert-info">No batches found</div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/admin/batches/index.blade.php ENDPATH**/ ?>