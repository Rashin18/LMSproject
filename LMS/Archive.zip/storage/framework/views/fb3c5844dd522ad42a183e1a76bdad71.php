<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <h2 class="mb-4">Edit Profile</h2>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    
    <form method="POST" action="<?php echo e(route('profile.update')); ?>" class="mb-4">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>

        <div class="mb-3">
            <label for="name" class="form-label">Name <span class="text-danger">*</span></label>
            <input
                type="text"
                id="name"
                name="name"
                value="<?php echo e(old('name', $user->name)); ?>"
                class="form-control"
                required
                autofocus
            >
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
            <input
                type="email"
                id="email"
                name="email"
                value="<?php echo e(old('email', $user->email)); ?>"
                class="form-control"
                required
            >
        </div>

        <hr class="my-4">

        <h4 class="mb-3">Change Password</h4>

        <div class="mb-3">
            <label for="current_password" class="form-label">Current Password</label>
            <input
                type="password"
                id="current_password"
                name="current_password"
                class="form-control"
                placeholder="Leave blank to keep current password"
            >
        </div>

        <div class="mb-3">
            <label for="new_password" class="form-label">New Password</label>
            <input
                type="password"
                id="new_password"
                name="new_password"
                class="form-control"
                placeholder="Leave blank to keep current password"
            >
            <div class="form-text">Minimum 8 characters</div>
        </div>

        <div class="mb-3">
            <label for="new_password_confirmation" class="form-label">Confirm New Password</label>
            <input
                type="password"
                id="new_password_confirmation"
                name="new_password_confirmation"
                class="form-control"
                placeholder="Confirm new password"
            >
        </div>

        <button type="submit" class="btn btn-primary">Update Profile</button>
    </form>

    
    <form method="POST" action="<?php echo e(route('profile.destroy')); ?>" onsubmit="return confirm('Are you sure you want to delete your profile? This action cannot be undone.');">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-danger">Delete Profile</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/profile/edit.blade.php ENDPATH**/ ?>