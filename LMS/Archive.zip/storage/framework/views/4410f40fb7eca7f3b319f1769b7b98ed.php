<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Reports Dashboard</h1>
        <div class="dropdown">
            <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="exportDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-download"></i> Export Reports
            </button>
            <ul class="dropdown-menu" aria-labelledby="exportDropdown">
                <li><a class="dropdown-item" href="<?php echo e(route('admin.reports.export', ['type' => 'students'])); ?>">Export Student Data</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('admin.reports.export', ['type' => 'teachers'])); ?>">Export Teacher Data</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('admin.reports.export', ['type' => 'courses'])); ?>">Export Course Data</a></li>
            </ul>
        </div>
    </div>

    <!-- Cards section remains the same -->
    <div class="row mb-4">
        <!-- ... your existing card code ... -->
    </div>

    <!-- Updated Recent Activity Section -->
    <div class="card shadow-sm">
        <div class="card-header bg-light">
            <h4 class="mb-0">Recent Activity</h4>
        </div>
        <div class="card-body">
            <?php if(isset($recentActivities) && $recentActivities->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Type</th>
                                <th>Description</th>
                                <th>User</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $recentActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><span class="badge bg-<?php echo e($activity->type_color ?? 'primary'); ?>"><?php echo e($activity->type ?? 'N/A'); ?></span></td>
                                <td><?php echo e($activity->description ?? 'No description'); ?></td>
                                <td><?php echo e($activity->user->name ?? 'System'); ?></td>
                                <td><?php echo e($activity->created_at->diffForHumans()); ?></td>
                                <td>
                                    <?php if(isset($activity->action_link)): ?>
                                        <a href="<?php echo e($activity->action_link); ?>" class="btn btn-sm btn-outline-primary">View</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">No recent activities found</div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/admin/reports/index.blade.php ENDPATH**/ ?>