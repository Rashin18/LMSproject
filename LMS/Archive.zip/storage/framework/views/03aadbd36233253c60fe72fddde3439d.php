<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">
            <h2>Submit Proposal for: <?php echo e($eoi->name); ?></h2>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.next-form.store', $eoi)); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label for="project_title" class="form-label">Project Title</label>
                    <input type="text" class="form-control" id="project_title" name="project_title" required>
                </div>

                <div class="mb-3">
                    <label for="detailed_description" class="form-label">Detailed Description</label>
                    <textarea class="form-control" id="detailed_description" name="detailed_description" rows="5" required></textarea>
                </div>

                <div class="mb-3">
                    <label for="budget" class="form-label">Estimated Budget</label>
                    <input type="number" class="form-control" id="budget" name="budget" required>
                </div>

                <!-- Add more fields as needed -->

                <button type="submit" class="btn btn-primary">Submit Proposal</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/admin/next-form/create.blade.php ENDPATH**/ ?>