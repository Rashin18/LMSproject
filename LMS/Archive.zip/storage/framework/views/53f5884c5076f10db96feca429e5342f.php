<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row mb-4">
        <div class="col">
            <h1 class="text-primary">Welcome, <?php echo e(auth()->user()->name); ?></h1>
            <p class="text-muted">Manage your applications and affiliations.</p>
            <?php if (isset($component)) { $__componentOriginal7ba61be6ae4c62d2088d368a74b5ebcc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ba61be6ae4c62d2088d368a74b5ebcc = $attributes; } ?>
<?php $component = App\View\Components\AnnouncementsList::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('announcements-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AnnouncementsList::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ba61be6ae4c62d2088d368a74b5ebcc)): ?>
<?php $attributes = $__attributesOriginal7ba61be6ae4c62d2088d368a74b5ebcc; ?>
<?php unset($__attributesOriginal7ba61be6ae4c62d2088d368a74b5ebcc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ba61be6ae4c62d2088d368a74b5ebcc)): ?>
<?php $component = $__componentOriginal7ba61be6ae4c62d2088d368a74b5ebcc; ?>
<?php unset($__componentOriginal7ba61be6ae4c62d2088d368a74b5ebcc); ?>
<?php endif; ?>
        </div>
    </div>

    <div class="row">
        <!-- Proposal Forms Card -->
        <?php if($pendingProposals->count()): ?>
        <div class="col-md-6 mb-4">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Pending Proposals</h5>
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $pendingProposals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proposal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <strong><?php echo e($proposal->project_title); ?></strong>
                                <div class="text-muted small">Created: <?php echo e($proposal->created_at->format('M d, Y')); ?></div>
                            </div>
                            <a href="<?php echo e(route('applicant.proposal-form.create', $proposal->id)); ?>" 
                               class="btn btn-sm btn-primary">
                                Complete Form
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Application Forms Card -->
        <?php if($pendingApplications->count()): ?>
        <div class="col-md-6 mb-4">
            <div class="card shadow">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0">Pending Applications</h5>
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $pendingApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <strong><?php echo e($application->proposal->project_title); ?></strong>
                                <div class="text-muted small">Created: <?php echo e($application->created_at->format('M d, Y')); ?></div>
                            </div>
                            <a href="<?php echo e(route('applicant.application-form.create', $application->id)); ?>" 
                               class="btn btn-sm btn-success">
                                Complete Form
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Affiliation Forms Card -->
        <?php if($pendingAffiliations->count()): ?>
        <div class="col-md-6 mb-4">
            <div class="card shadow">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0">Pending Affiliations</h5>
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $pendingAffiliations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $affiliation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <strong><?php echo e($affiliation->application->proposal->project_title); ?></strong>
                                <div class="text-muted small">Expires: <?php echo e($affiliation->token_expires_at->format('M d, Y')); ?></div>
                            </div>
                            <a href="<?php echo e(route('applicant.affiliation-form.create', $affiliation->id)); ?>" 
                               class="btn btn-sm btn-info">
                                Complete Form
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/applicant/dashboard.blade.php ENDPATH**/ ?>