<div class="mb-4">
    <form action="<?php echo e(route('admin.assignments.index')); ?>" method="GET">
        <div class="input-group">
            <input type="text" name="search" class="form-control" 
                   placeholder="Search assignments..." 
                   value="<?php echo e(request('search')); ?>">
            <div class="input-group-append">
                <button class="btn btn-primary" type="search">Search
                    <i class="fas fa-search"></i>
                </button>
                <?php if(request('search')): ?>
                <a href="<?php echo e(route('admin.assignments.index')); ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-times">Clear</i>
                </a>
                <?php endif; ?>
            </div>
        </div>
    </form>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/dashboard/LMS/resources/views/admin/assignments/partials/search.blade.php ENDPATH**/ ?>